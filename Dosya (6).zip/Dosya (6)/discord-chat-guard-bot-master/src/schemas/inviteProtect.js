const { Schema, model } = require("mongoose");

const schema = Schema({
  guildID: { type: String, default: "" },
  userID: { type: String, default: "" },
  count: { type: Number, default: 0 },
});

module.exports = model("bannedTag", schema);
